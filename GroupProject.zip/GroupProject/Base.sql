DROP DATABASE IF EXISTS Base;
CREATE DATABASE Base;
USE Base;

CREATE TABLE User (
	userID INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    username VARCHAR(20) NOT NULL,
    password VARCHAR(20) NOT NULL
);

INSERT INTO User(username, password)
	VALUES ("mingxual","Andy990402"),
		   ("Hanzo","handsome");
    
CREATE TABLE Score (
	scoreID INT(11) PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    timespent VARCHAR(50) NOT NULL
);
INSERT INTO Score(username,timespent)
	VALUES ("Hanzo","45");