package typeracer;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@SuppressWarnings({ "resource", "null" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("here");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String username = request.getParameter("username"), password = request.getParameter("password"), confirm = request.getParameter("confirm"), errorMsg = "";
		
		try {
			if( username.trim().length() == 0 || username == null ) {
				errorMsg += "The username cannot be blank.";
			}
			else if( password.trim().length() == 0 || password == null ) {
				errorMsg += "The password cannot be blank";
			}
			else if( password.trim().compareTo(confirm.trim()) != 0 ) {
				errorMsg += "The passwords do not match.";
			}
			
			if(errorMsg.trim().length() <= 0) {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Base?user=root&password=root");
				st = conn.createStatement();
				rs = st.executeQuery("SELECT * FROM User;");
				while( rs.next() ) {
					String curruser = rs.getString("username");
					if( username.trim().compareTo(curruser) == 0 ) {
						errorMsg += "This username is already taken.";
						break;
					}
				}
				if(errorMsg.trim().length() == 0) {
					st.executeUpdate("INSERT INTO User (username, password) " + "VALUES('" + username.trim() + "', '" + password.trim() + "')" );
				}
			}
			
			PrintWriter pw = response.getWriter();
			pw.println(errorMsg);
			pw.close();
			
			conn.close();
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
}
