package typeracer;

import java.util.Vector;

public class Wordcount {
	public int num;
	public Wordcount() {
		num = 0;
	}
	public int count(Vector<String> vec) {
		for(int i=0;i<vec.size();i++)
		{
			String temp = vec.get(i);
			String[] list = temp.split(" ");
			for(int j=0;j<list.length;j++)
			{
				if(list[j].trim().compareTo("")!=0)
				{
					num += 1;
				}
			}
		}
		return num;
	}
}
