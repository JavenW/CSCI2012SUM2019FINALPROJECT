package typeracer;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

public class readfile {
	public Vector<String> contents;
	
	public readfile() {
		contents = new Vector<String>();
	}
	
	public void read(String filename) {
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			while(line != null) {
				contents.add(line);
				line = br.readLine();
			}
		} catch (FileNotFoundException fnfe) {
		} catch (IOException ioe) {
		}
	}
}
