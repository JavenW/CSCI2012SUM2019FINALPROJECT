package typeracer;

import java.io.IOException;
import java.util.Vector;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint (value = "/Server")
public class Server {
	private static Vector<Session> sessionVector = new Vector<Session>();
	@OnOpen
	public void open(Session session) {
		//System.out.println("Connecting!");
		sessionVector.add(session);
		//System.out.println(sessionVector.size());
	}
	@OnMessage
	public void onMessage(String message, Session session) {
		try {
			//System.out.println(message);
			//System.out.println("here");
			for(int i = 0; i < sessionVector.size(); i++) {
				if(sessionVector.get(i) != session) sessionVector.get(i).getBasicRemote().sendText(message);
			}
		} catch(IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	@OnClose
	public void close(Session session) {
		//System.out.println("Disconnecting!");
		sessionVector.remove(session);
	}
	@OnError
	public void onError(Throwable Error) {
		System.out.println("Error!");
	}
}
